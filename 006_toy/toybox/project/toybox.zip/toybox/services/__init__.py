#
# import logging
# import logging.config

#from logging import basicConfig, DEBUG

# これはメインのファイルにのみ書く
# basicConfig(level=DEBUG)

# logging.config.fileConfig(os.path.dirname(os.path.abspath(__file__)) + '/../config/logging.conf', disable_existing_loggers=False)

# import requests
