#!/usr/bin/python
# -*- coding: utf-8 -*-

class helloService():

    def hello(request):
        return 'xxx'
