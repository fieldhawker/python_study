from django.apps import AppConfig


class CybozuliveConfig(AppConfig):
    name = 'cybozulive'
